<?php

namespace App\Http\Controllers;

use App\Models\işlemTürüPrimOranıModel;
use App\Models\satışElemanlarıHedefModel;
use App\Models\satışelemanlarımodel;
use App\Models\satışlarModel;
use Illuminate\Http\Request;


class mainController extends Controller
{
    public function index()
    {
        return view('index');
    }

    public function results()
    {
        $satışlarList=satışlarModel::all();

        $gayrimenkul=işlemTürüPrimOranıModel::where("id", 1)->first();
        $gayrimenkul_prim_oranı=(float)$gayrimenkul->prim_oranı;
        $hizmet_tedarik=işlemTürüPrimOranıModel::where("id", 2)->first();
        $hizmet_tedarik_prim_oranı=(float)$hizmet_tedarik->prim_oranı;
        $genel=işlemTürüPrimOranıModel::where("id", 3)->first();
        $genel_prim_oranı=(float)$genel->prim_oranı;

        $ilk_eleman_satış_sayısı=satışlarModel::where("satış_elemanları_id", 1)->count();
        $ilk_eleman_gayrimenkul_satış_sayısı=satışlarModel::where("satış_elemanları_id", 1)->where("işlem_türü_id", 1)->count();
        $ilk_eleman_hizmet_tedarik_satış_sayısı=satışlarModel::where("satış_elemanları_id", 1)->where("işlem_türü_id", 2)->count();
        $ilk_eleman_genel_satış_sayısı=satışlarModel::where("satış_elemanları_id", 1)->where("işlem_türü_id", 3)->count();

        $ilk_eleman_satış_miktarı=satışlarModel::where("satış_elemanları_id", 1)->sum("ürün_tutarı");
        $ilk_eleman_gayrimenkul_satış_miktarı=satışlarModel::where("satış_elemanları_id", 1)->where("işlem_türü_id", 1)->sum("ürün_tutarı");
        $ilk_eleman_hizmet_tedarik_satış_miktarı=satışlarModel::where("satış_elemanları_id", 1)->where("işlem_türü_id", 2)->sum("ürün_tutarı");
        $ilk_eleman_genel_satış_miktarı=satışlarModel::where("satış_elemanları_id", 1)->where("işlem_türü_id", 3)->sum("ürün_tutarı");


        $ilk_eleman_gayrimenkul_satış_prim_miktarı=$ilk_eleman_gayrimenkul_satış_miktarı / 100 * $gayrimenkul_prim_oranı;
        $ilk_eleman_hizmet_tedarik_satış_prim_miktarı=$ilk_eleman_hizmet_tedarik_satış_miktarı / 100 * $hizmet_tedarik_prim_oranı;
        $ilk_eleman_genel_satış_prim_miktarı=$ilk_eleman_genel_satış_miktarı / 100 * $genel_prim_oranı;
        $ilk_eleman_satış_prim_miktarı=$ilk_eleman_gayrimenkul_satış_prim_miktarı+$ilk_eleman_hizmet_tedarik_satış_prim_miktarı+$ilk_eleman_genel_satış_prim_miktarı;

        $ilk_eleman=satışElemanlarıHedefModel::where("satış_elemanları_id", 1)->first();

            $ilk_eleman_hedef_tutturma_oranı=$ilk_eleman_satış_miktarı*100/$ilk_eleman->hedef  ;


        $ikinci_eleman_satış_sayısı=satışlarModel::where("satış_elemanları_id", 2)->count();
        $ikinci_eleman_gayrimenkul_satış_sayısı=satışlarModel::where("satış_elemanları_id", 2)->where("işlem_türü_id", 1)->count();
        $ikinci_eleman_hizmet_tedarik_satış_sayısı=satışlarModel::where("satış_elemanları_id", 2)->where("işlem_türü_id", 2)->count();
        $ikinci_eleman_genel_satış_sayısı=satışlarModel::where("satış_elemanları_id", 2)->where("işlem_türü_id", 3)->count();

        $ikinci_eleman_satış_miktarı=satışlarModel::where("satış_elemanları_id", 2)->sum("ürün_tutarı");
        $ikinci_eleman_gayrimenkul_satış_miktarı=satışlarModel::where("satış_elemanları_id", 2)->where("işlem_türü_id", 1)->sum("ürün_tutarı");
        $ikinci_eleman_hizmet_tedarik_satış_miktarı=satışlarModel::where("satış_elemanları_id", 2)->where("işlem_türü_id", 2)->sum("ürün_tutarı");
        $ikinci_eleman_genel_satış_miktarı=satışlarModel::where("satış_elemanları_id", 2)->where("işlem_türü_id", 3)->sum("ürün_tutarı");

        $ikinci_eleman_gayrimenkul_satış_prim_miktarı=$ikinci_eleman_gayrimenkul_satış_miktarı / 100 * $gayrimenkul_prim_oranı;
        $ikinci_eleman_hizmet_tedarik_satış_prim_miktarı=$ikinci_eleman_hizmet_tedarik_satış_miktarı / 100 * $hizmet_tedarik_prim_oranı;
        $ikinci_eleman_genel_satış_prim_miktarı=$ikinci_eleman_genel_satış_miktarı / 100 * $genel_prim_oranı;
        $ikinci_eleman_satış_prim_miktarı=$ikinci_eleman_gayrimenkul_satış_prim_miktarı+$ikinci_eleman_hizmet_tedarik_satış_prim_miktarı+$ikinci_eleman_genel_satış_prim_miktarı;

        $ikinci_eleman=satışElemanlarıHedefModel::where("satış_elemanları_id", 2)->first();

            $ikinci_eleman_hedef_tutturma_oranı=$ikinci_eleman_satış_miktarı*100/$ikinci_eleman->hedef  ;


        $üçüncü_eleman_satış_sayısı=satışlarModel::where("satış_elemanları_id", 3)->count();
        $üçüncü_eleman_gayrimenkul_satış_sayısı=satışlarModel::where("satış_elemanları_id", 3)->where("işlem_türü_id", 1)->count();
        $üçüncü_eleman_hizmet_tedarik_satış_sayısı=satışlarModel::where("satış_elemanları_id", 3)->where("işlem_türü_id", 2)->count();
        $üçüncü_eleman_genel_satış_sayısı=satışlarModel::where("satış_elemanları_id", 3)->where("işlem_türü_id", 3)->count();

        $üçüncü_eleman_satış_miktarı=satışlarModel::where("satış_elemanları_id", 3)->sum("ürün_tutarı");
        $üçüncü_eleman_gayrimenkul_satış_miktarı=satışlarModel::where("satış_elemanları_id", 3)->where("işlem_türü_id", 1)->sum("ürün_tutarı");
        $üçüncü_eleman_hizmet_tedarik_satış_miktarı=satışlarModel::where("satış_elemanları_id", 3)->where("işlem_türü_id", 2)->sum("ürün_tutarı");
        $üçüncü_eleman_genel_satış_miktarı=satışlarModel::where("satış_elemanları_id", 3)->where("işlem_türü_id", 3)->sum("ürün_tutarı");

        $üçüncü_eleman_gayrimenkul_satış_prim_miktarı=$üçüncü_eleman_gayrimenkul_satış_miktarı / 100 * $gayrimenkul_prim_oranı;
        $üçüncü_eleman_hizmet_tedarik_satış_prim_miktarı=$üçüncü_eleman_hizmet_tedarik_satış_miktarı / 100 * $hizmet_tedarik_prim_oranı;
        $üçüncü_eleman_genel_satış_prim_miktarı=$üçüncü_eleman_genel_satış_miktarı / 100 * $genel_prim_oranı;
        $üçüncü_eleman_satış_prim_miktarı=$üçüncü_eleman_gayrimenkul_satış_prim_miktarı+$üçüncü_eleman_hizmet_tedarik_satış_prim_miktarı+$üçüncü_eleman_genel_satış_prim_miktarı;

        $üçüncü_eleman=satışElemanlarıHedefModel::where("satış_elemanları_id", 3)->first();

            $üçüncü_eleman_hedef_tutturma_oranı=$üçüncü_eleman_satış_miktarı*100/$üçüncü_eleman->hedef  ;


        return view('results', ['satışlarList' => $satışlarList,'ilk_eleman_satış_sayısı' => $ilk_eleman_satış_sayısı,
            'ikinci_eleman_satış_sayısı'=>$ikinci_eleman_satış_sayısı,'üçüncü_eleman_satış_sayısı'=>$üçüncü_eleman_satış_sayısı,
            'ilk_eleman_gayrimenkul_satış_sayısı'=>$ilk_eleman_gayrimenkul_satış_sayısı,
            'ilk_eleman_hizmet_tedarik_satış_sayısı'=>$ilk_eleman_hizmet_tedarik_satış_sayısı,
            'ilk_eleman_genel_satış_sayısı'=>$ilk_eleman_genel_satış_sayısı,
            'ikinci_eleman_gayrimenkul_satış_sayısı'=>$ikinci_eleman_gayrimenkul_satış_sayısı,
            'ikinci_eleman_hizmet_tedarik_satış_sayısı'=>$ikinci_eleman_hizmet_tedarik_satış_sayısı,
            'ikinci_eleman_genel_satış_sayısı'=>$ikinci_eleman_genel_satış_sayısı,
            'üçüncü_eleman_gayrimenkul_satış_sayısı'=>$üçüncü_eleman_gayrimenkul_satış_sayısı,
            'üçüncü_eleman_hizmet_tedarik_satış_sayısı'=>$üçüncü_eleman_hizmet_tedarik_satış_sayısı,
            'üçüncü_eleman_genel_satış_sayısı'=>$üçüncü_eleman_genel_satış_sayısı,
            'ilk_eleman_satış_miktarı'=>$ilk_eleman_satış_miktarı,
            'ilk_eleman_gayrimenkul_satış_miktarı'=>$ilk_eleman_gayrimenkul_satış_miktarı,
            'ilk_eleman_hizmet_tedarik_satış_miktarı'=>$ilk_eleman_hizmet_tedarik_satış_miktarı,
            'ilk_eleman_genel_satış_miktarı'=>$ilk_eleman_genel_satış_miktarı,
            'ikinci_eleman_satış_miktarı'=>$ikinci_eleman_satış_miktarı,
            'ikinci_eleman_gayrimenkul_satış_miktarı'=>$ikinci_eleman_gayrimenkul_satış_miktarı,
            'ikinci_eleman_hizmet_tedarik_satış_miktarı'=>$ikinci_eleman_hizmet_tedarik_satış_miktarı,
            'ikinci_eleman_genel_satış_miktarı'=>$ikinci_eleman_genel_satış_miktarı,
            'üçüncü_eleman_satış_miktarı'=>$üçüncü_eleman_satış_miktarı,
            'üçüncü_eleman_gayrimenkul_satış_miktarı'=>$üçüncü_eleman_gayrimenkul_satış_miktarı,
            'üçüncü_eleman_hizmet_tedarik_satış_miktarı'=>$üçüncü_eleman_hizmet_tedarik_satış_miktarı,
            'üçüncü_eleman_genel_satış_miktarı'=>$üçüncü_eleman_genel_satış_miktarı,
            'ilk_eleman_gayrimenkul_satış_prim_miktarı'=>$ilk_eleman_gayrimenkul_satış_prim_miktarı,
            'ilk_eleman_hizmet_tedarik_satış_prim_miktarı'=>$ilk_eleman_hizmet_tedarik_satış_prim_miktarı,
            'ilk_eleman_genel_satış_prim_miktarı'=>$ilk_eleman_genel_satış_prim_miktarı,
            'ilk_eleman_satış_prim_miktarı'=>$ilk_eleman_satış_prim_miktarı,
            'ikinci_eleman_gayrimenkul_satış_prim_miktarı'=>$ikinci_eleman_gayrimenkul_satış_prim_miktarı,
            'ikinci_eleman_hizmet_tedarik_satış_prim_miktarı'=>$ikinci_eleman_hizmet_tedarik_satış_prim_miktarı,
            'ikinci_eleman_genel_satış_prim_miktarı'=>$ikinci_eleman_genel_satış_prim_miktarı,
            'ikinci_eleman_satış_prim_miktarı'=>$ikinci_eleman_satış_prim_miktarı,
            'üçüncü_eleman_gayrimenkul_satış_prim_miktarı'=>$üçüncü_eleman_gayrimenkul_satış_prim_miktarı,
            'üçüncü_eleman_hizmet_tedarik_satış_prim_miktarı'=>$üçüncü_eleman_hizmet_tedarik_satış_prim_miktarı,
            'üçüncü_eleman_genel_satış_prim_miktarı'=>$üçüncü_eleman_genel_satış_prim_miktarı,
            'üçüncü_eleman_satış_prim_miktarı'=>$üçüncü_eleman_satış_prim_miktarı,
            'ilk_eleman'=>$ilk_eleman,
            'ikinci_eleman'=>$ikinci_eleman,
            'üçüncü_eleman'=>$üçüncü_eleman,
            'ilk_eleman_hedef_tutturma_oranı'=>$ilk_eleman_hedef_tutturma_oranı,
            'ikinci_eleman_hedef_tutturma_oranı'=>$ikinci_eleman_hedef_tutturma_oranı,
            'üçüncü_eleman_hedef_tutturma_oranı'=>$üçüncü_eleman_hedef_tutturma_oranı,
        ]);
    }

    public function hedef_post(Request $request)
    {

        $gayrimenkul_ürünleri = array( "Arsa", "Bina", "Apartman", "Ofis" );
        $hizmet_tedarik_ürünleri = array( "Yazılım Hizmeti", "Turizm Hizmeti", "Sağlık Hizmeti", "Ulaşım Hizmeti" );
        $genel_ürünleri = array( "İnşaat Malzemeleri", "Askeri Malzemeler", "Fabrika Malzemeleri", "Tıbbi Malzemeler" );

        satışlarModel::truncate();
        satışElemanlarıHedefModel::truncate();
        satışelemanlarımodel::whereNotNull('id')->delete();
        işlemTürüPrimOranıModel::whereNotNull('id')->delete();

        satışelemanlarımodel::create([
            "id"=>1,
            "İsim"=>"1.Satış Elemanı",
        ]);

        satışelemanlarımodel::create([
            "id"=>2,
            "İsim"=>"2.Satış Elemanı",
        ]);

        satışelemanlarımodel::create([
            "id"=>3,
            "İsim"=>"3.Satış Elemanı",
        ]);

        işlemTürüPrimOranıModel::create([
            "id"=>1,
            "İşlem_adı"=>"Gayrimenkul",
            "prim_oranı" => 5
        ]);

        işlemTürüPrimOranıModel::create([
            "id"=>2,
            "İşlem_adı"=>"Hizmet Tedarik",
            "prim_oranı" => 3
        ]);

        işlemTürüPrimOranıModel::create([
            "id"=>3,
            "İşlem_adı"=>"Genel",
            "prim_oranı" => 4
        ]);

        satışElemanlarıHedefModel::create([
            "satış_elemanları_id"=>1,
            "hedef"=>$request->hedef_1,
        ]);

        satışElemanlarıHedefModel::create([
            "satış_elemanları_id"=>2,
            "hedef"=>$request->hedef_2,
        ]);

        satışElemanlarıHedefModel::create([
            "satış_elemanları_id"=>3,
            "hedef"=>$request->hedef_3,
        ]);

        for($i = 0;$i<100;$i++)
        {
            satışlarModel::create([
                "satış_elemanları_id"=>rand(1,3),
                "işlem_türü_id"=>rand(1,3),
                "Ürün_adı"=>"Undefined",
                "ürün_tutarı"=>rand(10000,200000),
            ]);
        }

        for($i = 0;$i<100;$i++)
        {
            satışlarModel::where("işlem_türü_id", 1)->update([
                "ürün_adı"=>$gayrimenkul_ürünleri[array_rand($gayrimenkul_ürünleri)],
            ]);

            satışlarModel::where("işlem_türü_id", 2)->update([
                "ürün_adı"=>$hizmet_tedarik_ürünleri[array_rand($hizmet_tedarik_ürünleri)],
            ]);

            satışlarModel::where("işlem_türü_id", 3)->update([
                "ürün_adı"=>$genel_ürünleri[array_rand($genel_ürünleri)],
            ]);
        }


    }

}

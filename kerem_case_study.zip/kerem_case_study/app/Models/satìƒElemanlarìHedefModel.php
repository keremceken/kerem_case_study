<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class satışElemanlarıHedefModel extends Model
{
    protected $table= "satış_elemanları_hedef";
    protected $primaryKey= "id";
    protected $guarded= [];
}

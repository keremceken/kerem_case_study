<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class satışElemanlarıModel extends Model
{
    protected $table= "satış_elemanları";
    protected $primaryKey= "id";
    protected $guarded= [];
}

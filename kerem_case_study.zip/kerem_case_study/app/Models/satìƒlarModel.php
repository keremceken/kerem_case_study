<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class satışlarModel extends Model
{
    protected $table= "satışlar";
    protected $primaryKey= "id";
    protected $guarded= [];
}

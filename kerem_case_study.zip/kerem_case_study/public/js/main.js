/* Demo purposes only */
$(".hover").mouseleave(
    function () {
        $(this).removeClass("hover");
    }
);
$(document).ready(function(){
    $("#seen").hide();
    $("#hide").click(function(){
        $("p").hide();
        $("#hide").hide();
        $("#seen").show();
    });
    $("#seen").click(function(){
        window.location.reload();
    });

    $("#show").click(function(){
        $("p").show();
    });
});


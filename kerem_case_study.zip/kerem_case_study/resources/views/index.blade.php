<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<title>Simülasyonu Başlat</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="{{ URL::asset('css/main.css') }}" />
<script type="text/javascript" src="{{ URL::asset('js/main.js') }}"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">

<body>

<div id="align_center_button">
    <button class="custom-btn btn-3"><span>Simülasyonu Başlat</span></button>
</div>

<figure class="snip1559">
    <div class="profile-image"><img src="{{URL::asset('/images/1.eleman.jpg')}}" alt="profile-sample2" /></div>
    <figcaption>
        <h3>1.Satış elemanı</h3>
        <br>
        <p>Aylık Hedef</p>
        <br>
        <input type="text" id="hedef_1" name="hedef_1" placeholder="Örnek: 5.000.000"> ₺
    </figcaption>
</figure>
<figure class="snip1559">
    <div class="profile-image"><img src="{{URL::asset('/images/2.eleman.jpg')}}" alt="profile-sample2" /></div>
    <figcaption>
        <h3>2.Satış elemanı</h3>
        <br>
        <p>Aylık Hedef</p>
        <br>
        <input type="text" id="hedef_2" name="hedef_2" placeholder="Örnek: 5.000.000"> ₺
    </figcaption>
</figure>
<figure class="snip1559">
    <div class="profile-image"><img src="{{URL::asset('/images/3.eleman.jpg')}}" alt="profile-sample2" /></div>
    <figcaption>
        <h3>3.Satış elemanı</h3>
        <br>
        <p>Aylık Hedef</p>
        <br>
        <input type="text" id="hedef_3" name="hedef_3" placeholder="Örnek: 1.000.000"> ₺
    </figcaption>
</figure>
</body>
<script type="text/javascript">

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(".btn-3").click(function(e){

        e.preventDefault();

        var hedef_1 = $("input[name=hedef_1]").val();
        hedef_1=hedef_1.split('.').join("");
        var hedef_2 = $("input[name=hedef_2]").val();
        hedef_2=hedef_2.split('.').join("");
        var hedef_3 = $("input[name=hedef_3]").val();
        hedef_3=hedef_3.split('.').join("");


        if(hedef_1!="" && hedef_2!="" && hedef_3!="") {
            $.ajax({
                type: 'POST',
                url: "{{ route('hedef_post') }}",
                data: {hedef_1: hedef_1, hedef_2: hedef_2, hedef_3: hedef_3},
                success: function (data) {
                    location.href= "/results";
                }
            });


        }
    else{
            alert('Lütfen önce tüm satış elemanlarına aylık hedef atayınız!');
        }
    });

    function updateTextView(_obj){
        var num = getNumber(_obj.val());
        if(num==0){
            _obj.val('');
        }else{
            _obj.val(num.toLocaleString());
        }
    }
    function getNumber(_str){
        var arr = _str.split('');
        var out = new Array();
        for(var cnt=0;cnt<arr.length;cnt++){
            if(isNaN(arr[cnt])==false){
                out.push(arr[cnt]);
            }
        }
        return Number(out.join(''));
    }
    $(document).ready(function(){
        $('input[type=text]').on('keyup',function(){
            updateTextView($(this));
        });
    });

</script>
</html>

<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<title>Yeniden Başlat?</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="{{ URL::asset('css/main.css') }}" />
<script type="text/javascript" src="{{ URL::asset('js/main.js') }}"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">

<body>

<div id="align_center_button">
    <button class="custom-btn btn-3"><span>Yeniden Başlat?</span></button>
</div>

<figure class="snip1559">
    <div class="profile-image"><img src="{{URL::asset('/images/1.eleman.jpg')}}" alt="profile-sample2" /></div>
    <figcaption>
        <h3>1.Satış elemanı</h3>
        <br>
        <p>Toplam satış sayısı: {{$ilk_eleman_satış_sayısı}}</p>
        <p>"Gayrimenkul" satış sayısı: {{$ilk_eleman_gayrimenkul_satış_sayısı}}</p>
        <p>"Hizmet tedarik" satış sayısı: {{$ilk_eleman_hizmet_tedarik_satış_sayısı}}</p>
        <p>"Genel" satış sayısı: {{$ilk_eleman_genel_satış_sayısı}}</p>
        <br>
        <p>Toplam satış miktarı: {{number_format($ilk_eleman_satış_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Gayrimenkul" satış miktarı: {{number_format($ilk_eleman_gayrimenkul_satış_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Hizmet tedarik" satış miktarı: {{number_format($ilk_eleman_hizmet_tedarik_satış_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Genel" satış miktarı: {{number_format($ilk_eleman_genel_satış_miktarı, 2, ',', '.')}} ₺</p>
        <br>
        <p>Toplam satış prim miktarı: {{number_format($ilk_eleman_satış_prim_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Gayrimenkul" satış prim miktarı: {{number_format($ilk_eleman_gayrimenkul_satış_prim_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Hizmet tedarik" satış prim miktarı: {{number_format($ilk_eleman_hizmet_tedarik_satış_prim_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Genel" satış prim miktarı: {{number_format($ilk_eleman_genel_satış_prim_miktarı, 2, ',', '.')}} ₺</p>
        <br>
        <p>Hedef miktarı: {{number_format($ilk_eleman->hedef, 2, ',', '.')}} ₺</p>
        <p>Toplam satış miktarı: {{number_format($ilk_eleman_satış_miktarı, 2, ',', '.')}} ₺</p>
        <br>
        <p><strong>Hedef tutturma oranı</strong></p>
        <progress value="{{$ilk_eleman_hedef_tutturma_oranı}}" max="100"> {{$ilk_eleman_hedef_tutturma_oranı}}% </progress>
        <p>%{{number_format($ilk_eleman_hedef_tutturma_oranı, 2, ',', '')}}</p>
    </figcaption>
</figure>

<figure class="snip1559">
    <div class="profile-image"><img src="{{URL::asset('/images/2.eleman.jpg')}}" alt="profile-sample2" /></div>
    <figcaption>
        <h3>2.Satış elemanı</h3>
        <br>
        <p>Toplam satış sayısı: {{$ikinci_eleman_satış_sayısı}}</p>
        <p>"Gayrimenkul" satış sayısı: {{$ikinci_eleman_gayrimenkul_satış_sayısı}}</p>
        <p>"Hizmet tedarik" satış sayısı: {{$ikinci_eleman_hizmet_tedarik_satış_sayısı}}</p>
        <p>"Genel" satış sayısı: {{$ikinci_eleman_genel_satış_sayısı}}</p>
        <br>
        <p>Toplam satış miktarı: {{number_format($ikinci_eleman_satış_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Gayrimenkul" satış miktarı: {{number_format($ikinci_eleman_gayrimenkul_satış_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Hizmet tedarik" satış miktarı: {{number_format($ikinci_eleman_hizmet_tedarik_satış_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Genel" satış miktarı: {{number_format($ikinci_eleman_genel_satış_miktarı, 2, ',', '.')}} ₺</p>
        <br>
        <p>Toplam satış prim miktarı: {{number_format($ikinci_eleman_satış_prim_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Gayrimenkul" satış prim miktarı: {{number_format($ikinci_eleman_gayrimenkul_satış_prim_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Hizmet tedarik" satış prim miktarı: {{number_format($ikinci_eleman_hizmet_tedarik_satış_prim_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Genel" satış prim miktarı: {{number_format($ikinci_eleman_genel_satış_prim_miktarı, 2, ',', '.')}} ₺</p>
        <br>
        <p>Hedef miktarı: {{number_format($ikinci_eleman->hedef, 2, ',', '.')}} ₺</p>
        <p>Toplam satış miktarı: {{number_format($ikinci_eleman_satış_miktarı, 2, ',', '.')}} ₺</p>
        <br>
        <p><strong>Hedef tutturma oranı</strong></p>
        <progress value="{{$ikinci_eleman_hedef_tutturma_oranı}}" max="100"> {{$ikinci_eleman_hedef_tutturma_oranı}}% </progress>
        <p>%{{number_format($ikinci_eleman_hedef_tutturma_oranı, 2, ',', '')}}</p>
    </figcaption>
</figure>

<figure class="snip1559">
    <div class="profile-image"><img src="{{URL::asset('/images/3.eleman.jpg')}}" alt="profile-sample2" /></div>
    <figcaption>
        <h3>3.Satış elemanı</h3>
        <br>
        <p>Toplam satış sayısı: {{$üçüncü_eleman_satış_sayısı}}</p>
        <p>"Gayrimenkul" satış sayısı: {{$üçüncü_eleman_gayrimenkul_satış_sayısı}}</p>
        <p>"Hizmet tedarik" satış sayısı: {{$üçüncü_eleman_hizmet_tedarik_satış_sayısı}}</p>
        <p>"Genel" satış sayısı: {{$üçüncü_eleman_genel_satış_sayısı}}</p>
        <br>
        <p>Toplam satış miktarı: {{number_format($üçüncü_eleman_satış_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Gayrimenkul" satış miktarı: {{number_format($üçüncü_eleman_gayrimenkul_satış_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Hizmet tedarik" satış miktarı: {{number_format($üçüncü_eleman_hizmet_tedarik_satış_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Genel" satış miktarı: {{number_format($üçüncü_eleman_genel_satış_miktarı, 2, ',', '.')}} ₺</p>
        <br>
        <p>Toplam satış prim miktarı: {{number_format($üçüncü_eleman_satış_prim_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Gayrimenkul" satış prim miktarı: {{number_format($üçüncü_eleman_gayrimenkul_satış_prim_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Hizmet tedarik" satış prim miktarı: {{number_format($üçüncü_eleman_hizmet_tedarik_satış_prim_miktarı, 2, ',', '.')}} ₺</p>
        <p>"Genel" satış prim miktarı: {{number_format($üçüncü_eleman_genel_satış_prim_miktarı, 2, ',', '.')}} ₺</p>
        <br>
        <p>Hedef miktarı: {{number_format($üçüncü_eleman->hedef, 2, ',', '.')}} ₺</p>
        <p>Toplam satış miktarı: {{number_format($üçüncü_eleman_satış_miktarı, 2, ',', '.')}} ₺</p>
        <br>
        <p><strong>Hedef tutturma oranı</strong></p>
        <progress value="{{$üçüncü_eleman_hedef_tutturma_oranı}}" max="100"> {{$üçüncü_eleman_hedef_tutturma_oranı}}% </progress>
        <p>%{{number_format($üçüncü_eleman_hedef_tutturma_oranı, 2, ',', '')}}</p>
    </figcaption>
</figure>
</body>
<script type="text/javascript">

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(".btn-3").click(function(e){

        location.href= "/";

    });
</script>
</html>

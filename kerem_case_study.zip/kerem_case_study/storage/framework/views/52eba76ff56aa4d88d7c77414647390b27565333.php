<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<title>Page Title</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="<?php echo e(URL::asset('css/main.css')); ?>" />
<script type="text/javascript" src="<?php echo e(URL::asset('js/main.js')); ?>"></script>

<body>

<div id="hide">
<div id="align_center_button">
    <button class="custom-btn btn-3"><span>Simülasyonu Başlat</span></button>
</div>
</div>

<div id="seen">
<div id="align_center_button">
    <button class="custom-btn btn-3"><span>Yeniden Başlat?</span></button>
</div>
</div>

<figure class="snip1559">
    <div class="profile-image"><img src="<?php echo e(URL::asset('/images/1.eleman.jpg')); ?>" alt="profile-sample2" /></div>
    <figcaption>
        <h3>1.Satış elemanı</h3>
        <p>Aylık Hedef Miktarı: </p>
        <div class="icons"><a href="#"><i class="ion-social-reddit"></i></a>
            <a href="#"> <i class="ion-social-twitter"></i></a>
            <a href="#"> <i class="ion-social-vimeo"></i></a>
        </div>
    </figcaption>
</figure>
<figure class="snip1559">
    <div class="profile-image"><img src="<?php echo e(URL::asset('/images/2.eleman.jpg')); ?>" alt="profile-sample2" /></div>
    <figcaption>
        <h3>2.Satış elemanı</h3>
        <p>Aylık Hedef Miktarı: </p>
        <div class="icons"><a href="#"><i class="ion-social-reddit"></i></a>
            <a href="#"> <i class="ion-social-twitter"></i></a>
            <a href="#"> <i class="ion-social-vimeo"></i></a>
        </div>
    </figcaption>
</figure>
<figure class="snip1559">
    <div class="profile-image"><img src="<?php echo e(URL::asset('/images/3.eleman.jpg')); ?>" alt="profile-sample2" /></div>
    <figcaption>
        <h3>3.Satış elemanı</h3>
        <p>Aylık Hedef Miktarı: </p>
        <div class="icons"><a href="#"><i class="ion-social-reddit"></i></a>
            <a href="#"> <i class="ion-social-twitter"></i></a>
            <a href="#"> <i class="ion-social-vimeo"></i></a>
        </div>
    </figcaption>
</figure>
</body>
</html>
<?php /**PATH C:\Users\kceke\Desktop\kerem_case_study\resources\views/welcome.blade.php ENDPATH**/ ?>